#!/bin/bash
# These are the packages required for install on Arch Linux systems.
sudo pacman -Sy gcc qt4 eigen protobuf libdc1394 cmake v4l-utils jsoncpp

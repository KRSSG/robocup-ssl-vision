#!/bin/sh
protoc --cpp_out=cpp *.proto

